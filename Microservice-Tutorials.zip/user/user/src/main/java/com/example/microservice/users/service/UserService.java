package com.example.microservice.users.service;

import com.example.microservice.users.VO.Department;
import com.example.microservice.users.VO.ResponseTemplateVO;
import com.example.microservice.users.entity.Users;
import com.example.microservice.users.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Users saveUser(Users user) {
        log.info("Inside saveUser of UserService");
        return userRepository.save(user);
    }

    public ResponseTemplateVO getUserWithDepartment(Long userId) {
        ResponseTemplateVO vo=new ResponseTemplateVO();
        Users user=userRepository.findByUserId(userId);
        log.info("Inside getUserWithDepartment of UserService");

        Department department=restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+user.getDepartmentId(), Department.class);
        vo.setUser(user);
        vo.setDepartment(department);
        return vo;
    }

    public Users getUserById(Long userId) {
        return userRepository.findByUserId(userId);
    }
}
